# Relatorio de Troubleshooting - TESTE_ORAHO114
_Template Padrao DBA Master | gerado em 2026-10-07 06:48 | severidade: CRITICO | Health Score: 23/100_

## Diagnostico Support Platform
- **Hostname de referencia:** <hostname>
- **Evento de referencia:** Troubleshooting - TESTE_ORAHO114
- **Hipotese inicial:** [ANALISE AUTOMATICA - confirmar] candidatos por impacto: (1) SQL 6bs012havrj97 custoso: 246435s de duracao (concluido) (246435s); (2) Contencao recorrente: enq: TX - row lock contention em KIPREV.FO_TIPSALDOS_X_APORTE (106 min/7d) - mecanismo: Aumento de carga (mais trabalho, nao mais lento)
- **Hipotese atual:** [ANALISE AUTOMATICA - confirmar] candidatos por impacto: (1) SQL 6bs012havrj97 custoso: 246435s de duracao (concluido) (246435s); (2) Contencao recorrente: enq: TX - row lock contention em KIPREV.FO_TIPSALDOS_X_APORTE (106 min/7d) - mecanismo: Aumento de carga (mais trabalho, nao mais lento)
- **Dados coletados:** Contas expirando ou bloqueadas, Jobs do scheduler com falha (7 dias), Recursos do host (CPU e memoria), Undo: ORA-01555 e espaco, Distribuicao de esperas (ASH), Erros no Alert Log, Destinos de archive, Idade do backup por datafile (RPO real), Blocos corrompidos, Datafiles fora de ONLINE, Archive gerado por hora (24h), Deadlocks (ORA-00060), SQL repetido por literal (sem bind), Parse e shared pool, Esperas de redo, ASM Diskgroups, Tablespaces, Conformidade com as praticas Oracle, Mudancas no ambiente (30d), Regressao de SQL (top por impacto), Planos de execucao (base x recente), Historico de planos por SQL (30d), Regressao de SQL (top por impacto), Datafiles sem AUTOEXTEND, FRA (Fast Recovery Area), Saude da instancia, Objetos invalidos, Redo log switches (24h), TEMP por sessao, UNDO (retencao e erros), Versao e nivel de patch, Previsao de capacidade (dias ate encher), Latencia de I/O por arquivo, Carga - serie diaria por metrica (14d), Carga por modulo/aplicacao, Carga por modulo - serie diaria (14d), Bloqueios no historico (ASH, 7 dias), Top bloqueadores por modulo (ASH, 7 dias), Sessoes, SQL Monitor - 6bs012havrj97, Estatisticas de tabelas, Topologia do ambiente, BUFFER CACHE HIT RATIO, INDICES UNUSABLE, MEMORIA (SGA/PGA), LIMITES (PROCESSES/SESSIONS), TOP 10 SEGMENTOS, SGA DYNAMIC COMPONENTS
- **Acao Support Platform:**
  - [CRITICO] 12 job(s) com falha; pior: APLKPVEUL.SRI_FULL_212461749_3 (impacto: 12 execucao(oes)) -> Priorize por consequencia: job de negocio parado e incidente; job de manutencao parado e causa raiz futura. Veja ADDITIONAL_INFO para o erro exato.
  - [CRITICO] Destino de archive LOG_ARCHIVE_DEST_2 em ERROR (impacto: ERROR) -> Trate como incidente em curso: libere espaco no destino (ou na FRA), confirme o caminho em LOG_ARCHIVE_DEST_n e reabilite com ALTER SYSTEM SET LOG_ARCHIVE_DEST_STATE_n=ENABLE; depois force com ALTER SYSTEM ARCHIVE LOG ALL e confirme que o STATUS voltou a VALID.
  - [CRITICO] Troca de redo parada esperando archive (4038x) (impacto: risco de parada total) -> Verifique espaco do destino/FRA e se o backup de archive esta rodando. Trate como incidente: com o destino cheio, o banco para de aceitar transacao.
  - [CRITICO] TS_KPVI_01 com 97.1% de uso (impacto: 97.1% usado) -> Adicionar datafile/aumentar autoextend ou liberar espaco urgentemente.
  - [CRITICO] TS_KPVD_01 com 97.1% de uso (impacto: 97.1% usado) -> Adicionar datafile/aumentar autoextend ou liberar espaco urgentemente.
  - [CRITICO] SQL 94457ctfrrzws: +972s de DB time (impacto: +972s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
  - [CRITICO] SQL 8t3atdd30ggck: +892s de DB time (impacto: +892s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
  - [CRITICO] SQL aw93rt7v2mg6k: +892s de DB time (impacto: +892s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
  - [CRITICO] SQL a4303k897gsay: +777s de DB time (impacto: +777s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
  - [CRITICO] SQL 6p6djj7qjcbcf: +777s de DB time (impacto: +777s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
  - [CRITICO] SQL b7twtbc82w46v: +695s de DB time (impacto: +695s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
  - [CRITICO] SQL 4mkb7ug7a328x: +533s de DB time (impacto: +533s) -> Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
- **Riscos mitigados:** Acoes destrutivas (kill/rebuild/shrink) exibidas com aviso e rollback planejado antes de executar.
- **Escalado:** N/A
- **Status:** Investigando
- **Criado em:** 2026-10-07 06:48
- **Resolvido em:** -

## RCA
- **Timeline:** 
  - sem hora [inicio] Caso TESTE_ORAHO114 criado
- **Impacto:** 12369s de DB time perdidos em regressao de SQL; bloqueio com espera de ate 6360s; carga +6061% sobre o baseline
- **Causa Raiz:** [ANALISE AUTOMATICA - confirmar] candidatos por impacto: (1) SQL 6bs012havrj97 custoso: 246435s de duracao (concluido) (246435s); (2) Contencao recorrente: enq: TX - row lock contention em KIPREV.FO_TIPSALDOS_X_APORTE (106 min/7d) - mecanismo: Aumento de carga (mais trabalho, nao mais lento)
- **Solucao:** (1) Priorize por consequencia: job de negocio parado e incidente; job de manutencao parado e causa raiz futura. Veja ADDITIONAL_INFO para o erro exato. (2) Trate como incidente em curso: libere espaco no destino (ou na FRA), confirme o caminho em LOG_ARCHIVE_DEST_n e reabilite com ALTER SYSTEM SET LOG_ARCHIVE_DEST_STATE_n=ENABLE; depois force com ALTER SYSTEM ARCHIVE LOG ALL e confirme que o STATUS voltou a VALID. (3) Verifique espaco do destino/FRA e se o backup de archive esta rodando. Trate como incidente: com o destino cheio, o banco para de aceitar transacao.
- **Prevencao:** Monitoramento continuo do indicador afetado; baseline via AWR; revisao de estatisticas/planos e capacidade.

## Raciocinio - por que esta e a causa
_Hipoteses concorrentes pontuadas pela evidencia deste caso. A refutada fica na lista de proposito: saber o que ja foi descartado, e por que, e o que impede a proxima pessoa de refazer o caminho._

- **Aumento de carga (mais trabalho, nao mais lento)** - SUSTENTADA (12 ponto(s))
  - Porque: Cada execucao custa o mesmo de sempre e o TOTAL dobrou. Isso nao se resolve tunando SQL: se resolve contendo ou dimensionando a origem da carga.
  - Sustenta: Average Active Sessions: salto em 2026-09-29 (3.31 -> 5.58, +69%)
  - Sustenta: DBMS_SCHEDULER: carga +747% (748.9->6342.0)
  - Sustenta: (sem modulo): salto em 2026-09-27 (76.5 -> 4713, +6061%)
  - O que decide: A carga por hora comparada com o mesmo periodo de antes, e se o custo POR EXECUCAO ficou igual (carga) ou subiu (regressao) - cole `executions` + `elapsed_time`. (`sessoes/execucoes por hora (ASH ou AWR por snapshot)`)
- **Espaco em tablespace / undo / temp** - SUSTENTADA (8 ponto(s)) **[PODE PARAR O BANCO]**
  - Porque: Objeto sem espaco para crescer derruba transacao com erro, mesmo com o banco no ar.
  - Sustenta: ORA-01555 (3x) - Snapshot too old
  - Sustenta: undo_autoextend = NAO (recomendado: SIM)
  - Sustenta: 5 datafile(s) com AUTOEXTEND OFF em 5 tablespace(s)
  - O que decide: Qual tablespace, quanto falta e se ha autoextend com teto no datafile. (`check space_tablespace / space_datafiles`)
- **Recuperabilidade comprometida (backup falhando)** - SUSTENTADA (4 ponto(s)) **[RISCO DE PERDA DE DADO]**
  - Porque: Nao afeta a performance de hoje e e o achado mais grave que existe: sem backup valido, qualquer outro incidente vira perda de dado.
  - Sustenta: 1 datafile(s) NUNCA copiado(s) pelo RMAN
  - Sustenta: rman_controlfile_autobackup = OFF (padrao) (recomendado: ON)
  - O que decide: Data do ultimo backup FULL valido e se o archive necessario ainda existe. (`check rman_backups / v$rman_status`)
- **Concorrencia: sessoes presas em lock** - SUSTENTADA (3 ponto(s))
  - Porque: Uma sessao segura o recurso e as outras esperam. O banco esta saudavel em CPU e I/O: o que falta e a linha ser liberada.
  - Sustenta: Contencao recorrente: enq: TX - row lock contention em KIPREV.FO_TIPSALDOS_X_APORTE
  - O que decide: Quem e a sessao raiz (NIVEL 1) da cadeia e ha quanto tempo ela esta ativa sem commit. (`gv$session / blocking_session (check locks_blocking)`)

**Sintoma, nao causa** - o sinal e real, mas outra causa ja o explica; tratar aqui e gastar sem resolver:
- Redo / commit lento (log file sync) - explicado por **Aumento de carga (mais trabalho, nao mais lento)**

> **ALEM DO INCIDENTE - risco estrutural neste servidor.** Nao explica o sintoma que abriu o caso e e mais grave que ele: Espaco em tablespace / undo / temp; Recuperabilidade comprometida (backup falhando).

## Hipoteses ja descartadas
- Nenhuma hipotese descartada até agora.

## Resumo executivo
- **Operacao e infraestrutura** (CRITICO): Falha operacional ou de infraestrutura em curso: trate antes de investigar SQL.
- **ASH / Waits** (OK): Maior espera nao-CPU: User I/O (10% da atividade). Distribuicao de esperas saudavel (predominio de CPU/atividade normal).
- **Alert Log / Erros ORA-** (ATENCAO): 8 ocorrencia(s) de 3 erro(s) ORA- distintos. Erros de atencao a avaliar.
- **Integridade e recuperabilidade** (CRITICO): 2 achado(s) critico(s) de integridade ou recuperabilidade: tratar antes de qualquer tuning.
- **Parse, redo e deadlock** (CRITICO): Contencao em curso (parse, redo ou deadlock): trata-se de causa, nao de sintoma - atacar antes de tunar SQL individual.
- **Espaco (Tablespace / ASM)** (CRITICO): 3 objeto(s) CRITICO(S) (>=90%): TS_KPVI_01 (97%), TS_KPVD_01 (97%), USERS (94%). Acao de espaco recomendada.
- **Conformidade com as praticas Oracle** (ATENCAO): Conformidade 67% (37/55 itens). 18 desvio(s), 0 critico(s). Desvios a avaliar em janela.
- **Mudancas no ambiente** (ATENCAO): 50 mudanca(s) na janela do salto de carga - candidata(s) a causa raiz; validar com gestao de mudanca.
- **SQL Health Check - Regressao** (CRITICO): 20 SQL(s) com regressao material (8094s de DB time); 10 SQL(s) com regressao material (4273s de DB time). Regressao critica de SQL: priorizar o plano de acao (acoes.sql) e a comparacao de planos.
- **Saude e capacidade** (ATENCAO): 3 achado(s) de saude/capacidade: 5 datafile(s) com AUTOEXTEND OFF em 5 tablespace(s); 44 objeto(s) invalido(s) em 4 schema(s); 12 trocas de redo em 1 hora (pico em 2026-10-07 05).
- **Bugs, patches e falhas de manutencao** (OK): Versao, dicionario e backups sem falha registrada.
- **Previsao de capacidade (dias ate encher)** (ATENCAO): 2 em atencao (<= 90 dias). Planejar expansao no trimestre.
- **I/O / Storage** (OK): Pior latencia de leitura: D216BECF4/DATAFILE/sysaux.269.1225798313 = 5.4 ms. I/O dentro do esperado.
- **Carga / Workload Trend** (ATENCAO): 1 serie(s) com salto de carga; 1 modulo(s)/app com aumento de carga. Aumento de carga em atencao: monitorar e alinhar com a aplicacao.
- **Locks / Bloqueios** (CRITICO): Nenhuma sessao bloqueada no momento da coleta. 116 min de bloqueio acumulados nos ultimos 7 dias (ASH). maior causador: modulo JarLauncher. Ha bloqueio critico: recomenda-se acao imediata.
- **Sessoes / Instancia** (OK): 0 sessao(oes) com espera longa. Sessoes sem esperas longas relevantes.
- **SQL lento / SQL Monitor** (CRITICO): SQL 6bs012havrj97 com duracao 246435s (status DONE). SQL critico por duracao (ja concluido): priorizar tuning (indice/estatisticas/plano).
- **Estatisticas do Otimizador** (OK): 0 objeto(s) com estatisticas desatualizadas. Estatisticas atualizadas.
- **Topologia e cluster** (INFO): Standalone (ASM, CDB 1 PDB(s), GoldenGate habilitado (sem c…. Topologia consistente e cluster sem alerta.
- **Evidencias** (OK): 6 secao(oes) generica(s). Sem alertas destacados.

## Destaques da analise (carga, regressao, SQL pesado, bloqueio)
**Bloqueio / lock**
- [CRITICO] Contencao recorrente: enq: TX - row lock contention em KIPREV.FO_TIPSALDOS_X_APORTE (106 min/7d)
  - Acao: Revisar a transacao que atualiza a mesma linha/objeto em concorrencia (reduzir escopo e duracao, commitar mais cedo).

**Regressao de SQL**
- [CRITICO] SQL gurdq4ubnm0jj (KIPREV): +1474s de DB time (+1474s)
  - Acao: Mesmo plano, mais tempo, com FULL SCAN no caminho: avaliar o indice candidato sugerido em acoes.sql (validar seletividade) ou particionamento/purga se a tabela cresceu.
- [CRITICO] SQL 94457ctfrrzws: +972s de DB time (+972s)
  - Acao: Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.

**SQL de maior consumo**
- [CRITICO] SQL 6bs012havrj97 custoso: 246435s de duracao (concluido) (246435s)
  - Acao: SQL ja concluido: candidato a tuning, nao incidente ativo. Comparar com a execucao boa (DBMS_XPLAN.DISPLAY_AWR) antes de mexer.

**Carga acima do baseline**
- [ATENCAO] (sem modulo): salto em 2026-09-27 (76.5 -> 4713, +6061%) (+6061% no dia 2026-09-27)
  - Acao: Casar a DATA do salto com deploy/mudanca da aplicacao, novos jobs/batch e volume; alinhar capacidade com o time.
- [ATENCAO] DBMS_SCHEDULER: salto em 2026-10-06 (715 -> 6676, +834%) (+834% no dia 2026-10-06)
  - Acao: Casar a DATA do salto com deploy/mudanca da aplicacao, novos jobs/batch e volume; alinhar capacidade com o time.

## Plano de acao priorizado
_12 acao(oes) priorizada(s); 4 para AGORA._

**AGORA**

1. **[Recuperabilidade] Destino de archive LOG_ARCHIVE_DEST_2 em ERROR** (risco de executar: medio)
   - **Fazer**: Trate como incidente em curso: libere espaco no destino (ou na FRA), confirme o caminho em LOG_ARCHIVE_DEST_n e reabilite com ALTER SYSTEM SET LOG_ARCHIVE_DEST_STATE_n=ENABLE; depois force com ALTER SYSTEM ARCHIVE LOG ALL e confirme que o STATUS voltou a VALID.
   - **Porque**: ORA-00270: error creating archive log. Com o destino em erro o redo nao arquiva; quando os grupos derem a volta, TODA transacao para com ORA-00257.
   - **Validar**: Confirme STATUS=VALID em v$archive_dest_status e o novo RPO por datafile (v$backup_datafile). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

2. **[Disponibilidade] Contencao recorrente: enq: TX - row lock contention em KIPREV.FO_TIPSALDOS_X_APORTE** (risco de executar: nenhum)
   - **Fazer**: Revisar a transacao que atualiza a mesma linha/objeto em concorrencia (reduzir escopo e duracao, commitar mais cedo).
   - **Porque**: 106 min bloqueados em 7 dias, distribuidos em 2 janela(s) de hora; pior janela 2026-10-01 17 com 6160s e ate 11 sessao(oes) afetada(s). Nao aparece na arvore de bloqueio porque ja passou - lock e transitorio.
   - **Validar**: Reconecte a aplicacao e confirme o indicador que gerou o achado (expiracao, espaco, bloqueio). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

3. **[Disponibilidade] 12 job(s) com falha; pior: APLKPVEUL.SRI_FULL_212461749_3** (risco de executar: nenhum)
   - **Fazer**: Priorize por consequencia: job de negocio parado e incidente; job de manutencao parado e causa raiz futura. Veja ADDITIONAL_INFO para o erro exato.
   - **Porque**: 1 falha(s). Erro: REASON="Stop job called by user: 'APLKPVEUL'"
   - **Validar**: Reconecte a aplicacao e confirme o indicador que gerou o achado (expiracao, espaco, bloqueio). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

4. **[Disponibilidade] TS_KPVI_01 com 97.1% de uso** (risco de executar: medio)
   - **Fazer**: Adicionar datafile/aumentar autoextend ou liberar espaco urgentemente.
   - **Porque**: 97% do espaco alocado; autoextend DESLIGADO
   - **Validar**: Reconecte a aplicacao e confirme o indicador que gerou o achado (expiracao, espaco, bloqueio). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

**HOJE**

5. **[Performance] SQL 1c1cmwwr1g6fy: +118s de DB time** (risco de executar: nenhum)
   - **Fazer**: Regressao de PLANO: comparar os planos em planos.txt (DBMS_XPLAN.DISPLAY_AWR). Para estabilizar rapido, fixar o plano bom com SQL Plan Baseline (DBMS_SPM.LOAD_PLANS_FROM_AWR) e so depois tratar a causa.
   - **Porque**: 232.559s -> 350.317s; +51%; 1 exec; plano 2746079945->198519413
   - **Validar**: Compare o DB time do SQL/evento antes e depois, na mesma janela de carga. Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

6. **[Performance] SQL 6bs012havrj97 custoso: 246435s de duracao (concluido)** (risco de executar: nenhum)
   - **Fazer**: SQL ja concluido: candidato a tuning, nao incidente ativo. Comparar com a execucao boa (DBMS_XPLAN.DISPLAY_AWR) antes de mexer.
   - **Porque**: Status 'DONE'.
   - **Validar**: Compare o DB time do SQL/evento antes e depois, na mesma janela de carga. Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

7. **[Performance] SQL 94457ctfrrzws: +972s de DB time** (risco de executar: nenhum)
   - **Fazer**: Mesmo plano, mais tempo: tipicamente CRESCIMENTO DE DADOS ou contencao (I/O, CPU, lock). Comparar volume da tabela e a wait class dominante do periodo antes de mexer no SQL.
   - **Porque**: 329.59s -> 1301.73s; +295%; 1 exec
   - **Validar**: Compare o DB time do SQL/evento antes e depois, na mesma janela de carga. Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

8. **[Performance] SQL gurdq4ubnm0jj (KIPREV): +1474s de DB time** (risco de executar: nenhum)
   - **Fazer**: Mesmo plano, mais tempo, com FULL SCAN no caminho: avaliar o indice candidato sugerido em acoes.sql (validar seletividade) ou particionamento/purga se a tabela cresceu.
   - **Porque**: 5060.66s -> 6534.867s; +29%; 1 exec
   - **Validar**: Compare o DB time do SQL/evento antes e depois, na mesma janela de carga. Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

9. **[Performance] Troca de redo parada esperando archive (4038x)** (risco de executar: nenhum)
   - **Fazer**: Verifique espaco do destino/FRA e se o backup de archive esta rodando. Trate como incidente: com o destino cheio, o banco para de aceitar transacao.
   - **Porque**: O destino de archive nao consumiu no ritmo da geracao. Este e o estado imediatamente anterior ao banco travar com ORA-00257.
   - **Validar**: Compare o DB time do SQL/evento antes e depois, na mesma janela de carga. Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

**ESTA SEMANA**

10. **[Erro do banco] ORA-13780 (4x) - Erro Oracle (sem entrada no dicionario)** (risco de executar: nenhum)
   - **Fazer**: Erro sem entrada no dicionario: leia o contexto no alert log e os traces do mesmo horario. Se for recorrente, acrescente o codigo em mcp/erros_ora.json para o proximo plantao nao comecar do zero.
   - **Porque**: -- ERRO: ORA-13780: SQL statement does not exist.
   - **Validar**: Confirme que o codigo ORA- parou de aparecer no alert log depois da acao (e nao apenas que o sintoma sumiu). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

11. **[Erro do banco] ORA-01555 (3x) - Snapshot too old** (risco de executar: medio)
   - **Fazer**: 1) Compare a duracao da consulta (maxquerylen) com tuned_undoretention em v$undostat. 2) Se a consulta dura mais que a retencao, aumentar undo apenas adia: ataque a consulta. 3) Se a retencao encolheu por falta de espaco, amplie a tablespace de undo. 4) RETENTION GUARANTEE so com ciencia de que DML pode falhar. (ver MOS 1004510.6)
   - **Porque**: O undo necessario para a leitura consistente foi sobrescrito: a consulta durou mais que a retencao efetiva de undo. 2026-10-03 11:50:03 16    ORA-01555 caused by SQL statement below (SQL ID: 6cpq8nnk01…
   - **Validar**: Confirme que o codigo ORA- parou de aparecer no alert log depois da acao (e nao apenas que o sintoma sumiu). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

12. **[Erro do banco] ORA-1652 (1x) - Nao estendeu segmento temporario** (risco de executar: medio)
   - **Fazer**: 1) Antes de ampliar, ache o consumidor (v$sort_usage/v$tempseg_usage): quase sempre e um plano ruim gerando sort gigante. 2) Amplie a TEMP se o consumo for legitimo.
   - **Porque**: TEMP insuficiente para sort/hash - ou uma unica consulta consumindo tudo. 2026-10-01 04:24:57 16    ORA-1652: unable to extend temp segment by 89600 in tablesp…
   - **Validar**: Confirme que o codigo ORA- parou de aparecer no alert log depois da acao (e nao apenas que o sintoma sumiu). Depois, `COLETAR.py TESTE_ORAHO114 --conn ORAHO114 --completo` e confira que o achado saiu do relatorio.

## Correlacao com mudancas recentes
_Hipoteses a confirmar, nao causa provada: a mudanca abaixo e compativel com o achado no tempo e no tipo. Teste uma por vez (`CASO.py <caso> --hipotese "..."`)._

- **TS_KPVI_01 com 97.1% de uso** pode estar ligado a **DDL** de 2026-10-07 04:57 (0.1 dia(s) antes) em `KIPREV.IE_MOVI_FINC_OX_03` - confianca alta.
  - Porque: DDL altera estrutura: espaco, planos e objetos dependentes.
  - Mudanca: INDEX (VALID)
- **TS_KPVD_01 com 97.1% de uso** pode estar ligado a **DDL** de 2026-10-07 04:57 (0.1 dia(s) antes) em `KIPREV.IE_MOVI_FINC_OX_03` - confianca alta.
  - Porque: DDL altera estrutura: espaco, planos e objetos dependentes.
  - Mudanca: INDEX (VALID)
- **SQL 94457ctfrrzws: +972s de DB time** pode estar ligado a **STATS** de 2026-10-07 05:31 (0.1 dia(s) antes) em `"KIPREV"."TB_OPER_EVTL"` - confianca alta.
  - Porque: coleta de estatisticas muda o plano escolhido pelo otimizador.
  - Mudanca: gather_table_stats - 0 min
- **SQL 8t3atdd30ggck: +892s de DB time** pode estar ligado a **STATS** de 2026-10-07 05:31 (0.1 dia(s) antes) em `"KIPREV"."TB_OPER_EVTL"` - confianca alta.
  - Porque: coleta de estatisticas muda o plano escolhido pelo otimizador.
  - Mudanca: gather_table_stats - 0 min
- **SQL aw93rt7v2mg6k: +892s de DB time** pode estar ligado a **STATS** de 2026-10-07 05:31 (0.1 dia(s) antes) em `"KIPREV"."TB_OPER_EVTL"` - confianca alta.
  - Porque: coleta de estatisticas muda o plano escolhido pelo otimizador.
  - Mudanca: gather_table_stats - 0 min
- **SQL a4303k897gsay: +777s de DB time** pode estar ligado a **STATS** de 2026-10-07 05:31 (0.1 dia(s) antes) em `"KIPREV"."TB_OPER_EVTL"` - confianca alta.
  - Porque: coleta de estatisticas muda o plano escolhido pelo otimizador.
  - Mudanca: gather_table_stats - 0 min
- **SQL 6p6djj7qjcbcf: +777s de DB time** pode estar ligado a **STATS** de 2026-10-07 05:31 (0.1 dia(s) antes) em `"KIPREV"."TB_OPER_EVTL"` - confianca alta.
  - Porque: coleta de estatisticas muda o plano escolhido pelo otimizador.
  - Mudanca: gather_table_stats - 0 min
- **SQL b7twtbc82w46v: +695s de DB time** pode estar ligado a **STATS** de 2026-10-07 05:31 (0.1 dia(s) antes) em `"KIPREV"."TB_OPER_EVTL"` - confianca alta.
  - Porque: coleta de estatisticas muda o plano escolhido pelo otimizador.
  - Mudanca: gather_table_stats - 0 min

## Mudancas desde a ultima analise
Primeira analise do caso (sem historico para comparar).

## Reincidencia no mesmo servidor
- Nenhum achado atual ja havia aparecido neste servidor na janela de 30 dias (ou nao ha historico suficiente).

## Proximos passos sugeridos (read-only)
- **SQL 94457ctfrrzws: +972s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 94457ctfrrzws --conn ORAHO114
  ```
- **SQL 8t3atdd30ggck: +892s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 8t3atdd30ggck --conn ORAHO114
  ```
- **SQL aw93rt7v2mg6k: +892s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 aw93rt7v2mg6k --conn ORAHO114
  ```
- **SQL a4303k897gsay: +777s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 a4303k897gsay --conn ORAHO114
  ```
- **SQL 6p6djj7qjcbcf: +777s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 6p6djj7qjcbcf --conn ORAHO114
  ```
- **SQL b7twtbc82w46v: +695s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 b7twtbc82w46v --conn ORAHO114
  ```
- **SQL 4mkb7ug7a328x: +533s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 4mkb7ug7a328x --conn ORAHO114
  ```
- **SQL gx0b6tj7kztp8: +533s de DB time**
  ```
  .\.venv\Scripts\python.exe DETALHAR_SQL.py TESTE_ORAHO114 gx0b6tj7kztp8 --conn ORAHO114
  ```

## Investigacao avancada (escreve no banco)
SQL Tuning Advisor ja executado neste caso - veja `advisor.txt` e a secao do advisor no `acoes.sql`.

---
_Dashboard: TESTE_ORAHO114.html | Apresentacao: TESTE_ORAHO114.pptx_
